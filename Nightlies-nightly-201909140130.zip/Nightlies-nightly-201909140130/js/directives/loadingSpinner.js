DuckieTV.directive('loadingSpinner', function() {
  return {
    restrict: 'E',
    template: '<div class="loading-spinner"> <div></div> <div></div> </div>'
  }
})
